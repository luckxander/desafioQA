package io.cucumber.desafio.StepDefinitions;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/io/cucumber/desafio/features",
        glue = "io/cucumber/desafio/StepDefinitions",
        plugin = {"pretty"} 
        )
public class RunCucumberTest{
	
}
