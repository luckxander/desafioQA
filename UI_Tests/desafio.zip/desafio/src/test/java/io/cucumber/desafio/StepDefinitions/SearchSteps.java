package io.cucumber.desafio.StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.boot.test.context.SpringBootTest;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

@SpringBootTest

public class SearchSteps {
	
	WebDriver dr = null;
	
	@Given("^I am in the search page$")
	public void i_am_in_the_search_page() throws Throwable {
		   System.setProperty("webdriver.chrome.driver","C:\\ProjetosGit\\desafio\\chromedriver.exe");
	       dr = new ChromeDriver();
	       dr.manage().window().maximize();
	       dr.navigate().to("http://automationpractice.com/");  
	}

	@When ("^I search for \"([^\"]*)\"$")
	public void i_search_for(String item_name) throws Throwable {
	       dr.findElement(By.xpath("//*[@id=\"search_query_top\"]")).sendKeys(item_name);
	}
	
	@And ("^I click the search button$")
	public void i_click_the_search_button() throws Throwable {
		   dr.findElement(By.name("submit_search")).click();
	}
	

	@Then("^\"([^\"]*)\" should be mentioned in the results$")	 
	public void should_be_mentioned_in_the_results(String item_name) throws Throwable {
		  TimeUnit.SECONDS.sleep(10);
	      String expectedText = item_name.toUpperCase();
	      String actualText = dr.findElement(By.xpath("//*[@id=\"center_column\"]/h1/span[1]")).getText();
	      //System.out.println(expectedText);
	      actualText = actualText.replace("\"", "");
	      //System.out.println(actualText);
	      Assert.assertTrue("Item mentioned in results",expectedText.equals(actualText));
	}

}
