package io.cucumber.desafio.StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.boot.test.context.SpringBootTest;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

@SpringBootTest
public class LoginSteps {

	WebDriver dr = null;
	
	@Given("^I am in authentication page$")
	public void i_am_in_authentication_page() throws Throwable {
		   System.setProperty("webdriver.chrome.driver","C:\\ProjetosGit\\desafio\\chromedriver.exe");
	       dr = new ChromeDriver();
	       dr.manage().window().maximize();
	       dr.navigate().to("http://automationpractice.com/index.php?controller=authentication&back=my-account");  
	}

	@When ("^I type my email address as \"([^\"]*)\"$")
	public void i_type_my_email_address(String email) throws Throwable {
	       dr.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(email);
	}
	
	@And ("^I type my password as \"([^\"]*)\"$")
	public void i_type_my_password(String password) throws Throwable {
		   dr.findElement(By.xpath("//*[@id=\"passwd\"]")).sendKeys(password);
	}
	
	@And ("^I click Sign in$") 
	public void i_click_sign_in() throws Throwable {
		   dr.findElement(By.xpath("//*[@id=\"SubmitLogin\"]")).click();
	}

	@Then("^I should be logged in to my account$")	 
	public void i_should_be_logged_in_to_my_account() throws Throwable {
		  TimeUnit.SECONDS.sleep(10);
	      String expectedText = "MY ACCOUNT";
	      String actualText = dr.findElement(By.xpath("//*[@id=\"center_column\"]/h1")).getText();
	      //System.out.println(actualText);
	      Assert.assertTrue("Login successful",expectedText.equals(actualText));
	}
}